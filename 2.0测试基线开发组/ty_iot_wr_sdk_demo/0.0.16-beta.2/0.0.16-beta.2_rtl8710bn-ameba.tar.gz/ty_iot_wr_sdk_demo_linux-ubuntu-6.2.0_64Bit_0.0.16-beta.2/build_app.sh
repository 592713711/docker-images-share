#!/bin/sh

APP_PATH=$1
APP_NAME=$2
APP_VERSION=$3
echo APP_PATH=$APP_PATH
echo APP_NAME=$APP_NAME
echo APP_VERSION=$APP_VERSION


fatal() {
    echo -e "\033[0;31merror: $1\033[0m"
    exit 1
}


[ -z $APP_PATH ] && fatal "no app path!"
[ -z $APP_NAME ] && fatal "no app name!"
[ -z $APP_VERSION ] && fatal "no version!"


cd `dirname $0`

TARGET_PLATFORM=linux-ubuntu-6.2.0_64Bit
TOOLCHAIN_PATH=$(pwd)/platforms/$TARGET_PLATFORM/toolchain

. $TOOLCHAIN_PATH/build_path
if [ -z "$TUYA_SDK_BUILD_PATH" ];then
    COMPILE_PREX=
else
    COMPILE_PREX=$(pwd)/platforms/$TARGET_PLATFORM/toolchain/$TUYA_SDK_BUILD_PATH
fi

cd $APP_PATH
make COMPILE_PREX=$COMPILE_PREX APP_BIN_NAME=$APP_NAME USER_SW_VER=$APP_VERSION all


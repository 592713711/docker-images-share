 /*============================================================================
 *                                                                            *
 * Copyright (C) by Tuya Inc                                                  *
 * All rights reserved                                                        *
 *                                                                            *
 =============================================================================*/

#ifndef __TY_SPI_H__
#define __TY_SPI_H__
/*============================ INCLUDES ======================================*/
#include "ty_hal.h"

/*============================ MACROS ========================================*/
#define TY_SPI_CPHA             (1 << 0)
#define TY_SPI_CPOL             (1 << 1)
#define TY_SPI_MODE_MASK        (TY_SPI_CPHA | TY_SPI_CPOL)

/*============================ TYPES =========================================*/
typedef enum {
    TY_SPI0  = 1,                  
    TY_SPI1,          
} TY_SPI_PORT_E;

typedef enum {
    TY_SPI_MODE0  = (0 | 0),                      //! CPOL = 0, CPHA = 0 
    TY_SPI_MODE1  = (0 | TY_SPI_CPHA),            //! CPOL = 0, CPHA = 1 
    TY_SPI_MODE2  = (TY_SPI_CPOL | 0),            //! CPOL = 1, CPHA = 0 
    TY_SPI_MODE3  = (TY_SPI_CPOL | TY_SPI_CPHA)   //! CPOL = 1, CPHA = 1 
} TY_SPI_MODE_E;

typedef enum {
    TY_SPI_DATA_BIT8  = 0,                     
    TY_SPI_DATA_BIT16,           
} TY_SPI_DATA_BITS_E;

typedef enum {
    TY_SPI_CS_MODE_AUTO  = 0,           //! hardware auto set            
    TY_SPI_CS_MODE_SOFT,                //! software manual set
} TY_SPI_CS_MODE_E;

typedef struct {
    UINT8_T         cs_pin;
} TY_SPI_CFG_S;

typedef struct {
    VOID        *send_buf;
    VOID        *recv_buf;
    UINT_T      length;
} TY_SPI_MSG_S;

typedef struct {
    TY_SPI_PORT_E           port;
    TY_SPI_MODE_E           mode;
    TY_SPI_DATA_BITS_E      data_bits;
    TY_SPI_CS_MODE_E        cs_mode;
    UINT_T                  freq_hz;
    UINT8_T                 flag;
} TY_SPI_BUS_CFG_S;


typedef struct {
    INT_T (*init)         (UINT8_T PORT, TY_SPI_BUS_CFG_S *cfg);
    INT_T (*xfer)         (UINT8_T PORT, TY_SPI_MSG_S *msg);
    INT_T (*control)      (UINT8_T port, UINT8_T cmd, VOID *arg);
    INT_T (*deinit)       (UINT8_T PORT);
} TY_SPI_BUS_OPS_S;


typedef struct {
    TY_SPI_BUS_CFG_S        cfg;
    MUTEX_HANDLE            lock;
    UINT8_T                 ref_count;
    TY_SPI_BUS_OPS_S        *ops;
} TY_SPI_BUS_S;

typedef struct {
    UINT8_T                 port;
    TY_SPI_CFG_S            cfg;    
    TY_SPI_BUS_S            *bus;
} TY_SPI_DEV_S;

/*============================ PROTOTYPES ====================================*/
INT_T ty_spi_bus_init(TY_SPI_BUS_CFG_S  *cfg);
INT_T ty_spi_bus_add_device(TY_SPI_DEV_S  *spi);

INT_T ty_spi_xfer(TY_SPI_DEV_S                  *spi,
                        VOID                    *send_buf,
                        VOID                    *recv_buf,
                        UINT_T                  length);

INT_T ty_spi_xfer_msg(TY_SPI_DEV_S              *spi,
                            TY_SPI_MSG_S        *msg,
                            UINT8_T             num);

INT_T ty_spi_exchange(TY_SPI_DEV_S              *spi,
                            UINT16_T            out,
                            UINT16_T            *in);

#define ty_spi_send_then_send(spi, send1, len1, send2, len2)        \
    do {                                                            \
        TY_SPI_MSG_S    msg[2];                                     \
        msg[0].send_buf = send1;                                    \
        msg[0].recv_buf = NULL;                                     \
        msg[0].length   = len1;                                     \
        msg[1].send_buf = send2;                                    \
        msg[1].recv_buf = NULL;                                     \
        msg[1].length   = len2;                                     \
        ty_spi_xfer_msg(spi, msg, 2);                               \
    } while (0)

#define ty_spi_send_then_recv(spi, send, len1, recv, len2)          \
    do {                                                            \
        TY_SPI_MSG_S    msg[2];                                     \
        msg[0].send_buf = send;                                     \
        msg[0].recv_buf = NULL;                                     \
        msg[0].length   = len1;                                     \
        msg[1].send_buf = NULL;                                     \
        msg[1].recv_buf = recv;                                     \
        msg[1].length   = len2;                                     \
        ty_spi_xfer_msg(spi, msg, 2);                               \
    } while (0)


#define ty_spi_send(spi, buf, len)                                  \
    ty_spi_xfer(spi, buf, NULL, len)

#define ty_spi_recv(spi, buf, len)                                  \
    ty_spi_xfer(spi, NULL, buf, len)


TY_SPI_BUS_S *ty_spi_bus_get(TY_SPI_PORT_E  port);

#endif

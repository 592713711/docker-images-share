 /*============================================================================
 *                                                                            *
 * Copyright (C) by Tuya Inc                                                  *
 * All rights reserved                                                        *
 *                                                                            *
 =============================================================================*/
 
#ifndef __TY_HAL_H__
#define __TY_HAL_H__

#include "tuya_cloud_types.h"
#include "tuya_global_errcode.h"
#include "uni_log.h"
#include "uni_mutex.h"

#define TY_HAL_ASSRET(__EXPRESS)                    \
    if (!(__EXPRESS))  {                            \
        PR_ERR("TY HAL ASSERT"#__EXPRESS"");        \
        while(1);                                   \
    }                                    

typedef enum {
    TY_HAL_INT_RX_FLAG = 0x01,
    TY_HAL_INT_TX_FLAG = 0x02,
    TY_HAL_DMA_RX_FLAG = 0x04,          
    TY_HAL_DMA_TX_FLAG = 0x08,
} TY_HAL_FLAG_E;

typedef enum {
    TY_HAL_RESUME_CMD  = 0x00,
    TY_HAL_SUSPEND_CMD,
    TY_HAL_SET_INT_CMD,          
    TY_HAL_CLR_INT_CMD
} TY_HAL_CMD_E;

#include "ty_pin.h"
#include "ty_uart.h"
#include "ty_timer.h"
#include "ty_pwm.h"
#include "ty_i2c.h"
#include "ty_spi.h"
#include "ty_adc.h"
#include "ty_i2s.h"

#endif

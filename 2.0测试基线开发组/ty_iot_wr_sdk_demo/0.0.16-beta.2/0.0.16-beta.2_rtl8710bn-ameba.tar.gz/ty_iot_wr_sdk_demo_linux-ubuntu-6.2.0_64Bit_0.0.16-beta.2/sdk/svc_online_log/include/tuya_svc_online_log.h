/**
 * @file tuya_svc_online_log.h
 * @author maht@tuya.com
 * @brief log服务的外部接口
 * @version 0.1
 * @date 2019-08-29
 * 
 * @copyright Copyright (c) tuya.inc 2019
 * 
 */

#ifndef __TUYA_SVC_ONLINE_LOG_H__
#define __TUYA_SVC_ONLINE_LOG_H__

#include "tuya_cloud_types.h"
#include "tuya_cloud_error_code.h"
#include "ty_cJSON.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief tuya online log service初始化
 * 
 * @param[in] p_env： system env
 * @param[in] p_log_seq_path： online log日志序文件存储路径
 * @return int: 0成功，非0，请参照tuya error code描述文档
 */
int tuya_svc_online_log_init(const char *p_env, const char *p_log_seq_path);

/**
 * @brief 
 * 
 * @param[in] active_flag 
 * @return int: 
 */
int tuya_svc_online_log_register();

/**
 * @brief 
 * 
 * @param[in] unactive_flag 
 * @return int: 
 */
int tuya_svc_online_log_unregister();

/**
 * @brief 
 * 
 * @param[in] active_flag 
 * @return int: 
 */
int tuya_svc_online_log_active(const char active_flag);

/**
 * @brief 
 * 
 * @param[in] unactive_flag 
 * @return int: 
 */
int tuya_svc_online_log_unactive(const char unactive_flag);

/**
 * @brief 
 * 
 * @param[in] reset_flag 
 * @return int: 
 */
int tuya_svc_online_log_reset(const char reset_flag);

/**
 * @brief 用户运行状态log上传
 * 
 * @param[in] p_log: log字符串 
 * @return int: 0成功，非0，请参照tuya error code描述文档 
 */
int tuya_svc_online_log_upload_runstat(const char *p_log);

/**
 * @brief 用户实时log上传
 * 
 * @param p_log: log字符串  
 * @return int: 0成功，非0，请参照tuya error code描述文档 
 */
int tuya_svc_online_log_upload_realtime(const char *p_log);

#ifdef __cplusplus
}
#endif
#endif


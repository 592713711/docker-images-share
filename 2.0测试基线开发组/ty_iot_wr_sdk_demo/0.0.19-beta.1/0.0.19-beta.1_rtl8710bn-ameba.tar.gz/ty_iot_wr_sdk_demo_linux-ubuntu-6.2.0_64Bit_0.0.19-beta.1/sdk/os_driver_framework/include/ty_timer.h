 /*============================================================================
 *                                                                            *
 * Copyright (C) by Tuya Inc                                                  *
 * All rights reserved                                                        *
 *                                                                            *
 * @author  :   Linch                                                         *
 * @date    :   2019-08-20                                                    *
 * @brief   :                                                                 *
 *                                                                            *
 =============================================================================*/

#ifndef __TY_TIMER_H__
#define __TY_TIMER_H__

/*============================ INCLUDES ======================================*/
#include "ty_hal.h"

/*============================ MACROS ========================================*/
/*============================ TYPES =========================================*/
typedef enum {
    TY_TIMER0 = 0,
    TY_TIMER1,
} TY_TIMER_PORT_E;

typedef enum {
    TY_TIMER_MODE_ONCE = 0,
    TY_TIMER_MODE_PERIOD
} TY_TIMER_MODE_T;


typedef VOID (*TY_TIMER_CB)(VOID *args);

typedef struct {
    UINT8_T             mode;
    TY_TIMER_CB         cb;
    VOID                *arg;
} TY_TIMER_CFG_S;

typedef struct {
    UINT8_T             support_freq;
    UINT_T              maxcount;
} TY_TIMER_INFO_S;


//! FOR PORT
typedef struct {
    INT_T (*init)     (UINT8_T  port, TY_TIMER_CFG_S *cfg);
    INT_T (*start)    (UINT8_T  port, UINT_T us);
    INT_T (*stop)     (UINT8_T  port);
    INT_T (*control)  (UINT8_T  port, UINT8_T cmd, VOID *arg);
    INT_T (*deinit)   (UINT8_T  port);
} TY_TIMER_OPS_S;

typedef struct {
    UINT8_T             port;
    TY_TIMER_CFG_S      cfg;
    TY_TIMER_OPS_S      *ops;
} TY_TIMER_DEV_S;

/*============================ LOCAL VARIABLES ===============================*/
/*============================ PROTOTYPES ====================================*/
INT_T ty_timer_init(TY_TIMER_DEV_S *timer);
INT_T ty_timer_start(TY_TIMER_DEV_S *timer, UINT_T us);
INT_T ty_timer_stop(TY_TIMER_DEV_S *timer);
INT_T ty_timer_control(TY_TIMER_DEV_S *timer, UINT8_T cmd, VOID *arg);
INT_T ty_timer_deinit(TY_TIMER_DEV_S *timer);


INT_T ty_timer_register(TY_TIMER_DEV_S  *timer);
#endif

 /*============================================================================
 *                                                                            *
 * Copyright (C) by Tuya Inc                                                  *
 * All rights reserved                                                        *
 *                                                                            *
 =============================================================================*/

#ifndef __TY_UART_H__
#define __TY_UART_H__

/*============================ INCLUDES ======================================*/
#include "ty_hal.h"

/*============================ MACROS ========================================*/
#define TY_UART_8N1_CFG_INIT(__CFG, __BAUDRATE, __BUFSZ)                    \
        __CFG.baudrate  = __BAUDRATE;                                       \
        __CFG.bufsz     = __BUFSZ;                                          \
        __CFG.flag      = TY_HAL_INT_RX_FLAG;                               \
        __CFG.data_bits = TY_UART_DATA_BIT8;                                \
        __CFG.stop_bits = TY_UART_STOP_BIT1;                                \
        __CFG.parity    = TY_UART_PARITY_NONE                               \

/*============================ TYPES =========================================*/
typedef enum {
    TY_UART0 = 0x00,
    TY_UART1,
} TY_UART_PORT_E;

typedef enum {
    TY_UART_BAUDRATE_300        = 300,
    TY_UART_BAUDRATE_600        = 600,
    TY_UART_BAUDRATE_1200       = 1200,
    TY_UART_BAUDRATE_2400       = 2400,
    TY_UART_BAUDRATE_4800       = 4800,
    TY_UART_BAUDRATE_9600       = 9600,
    TY_UART_BAUDRATE_19200      = 19200,
    TY_UART_BAUDRATE_38400      = 38400,
    TY_UART_BAUDRATE_57600      = 57600,
    TY_UART_BAUDRATE_74880      = 74880,
    TY_UART_BAUDRATE_115200     = 115200,
    TY_UART_BAUDRATE_230400     = 230400,
    TY_UART_BAUDRATE_460800     = 460800,
    TY_UART_BAUDRATE_921600     = 921600,
    TY_UART_BAUDRATE_1500000    = 1500000,
    TY_UART_BAUDRATE_1843200    = 1843200,
    TY_UART_BAUDRATE_3686400    = 3686400,
} TY_UART_BAUDRATE_E;

typedef enum {
    TY_UART_DATA_BIT5           = 0x00,
    TY_UART_DATA_BIT6           = 0x01,
    TY_UART_DATA_BIT7           = 0x02,
    TY_UART_DATA_BIT8           = 0x03,
} TY_UART_DATA_BITS_E;

typedef enum {
    TY_UART_STOP_BIT1           = 0x01,
    TY_UART_STOP_BIT1_5         = 0x02,
    TY_UART_STOP_BIT2           = 0x03,
} TY_UART_STOP_BITS_E;

typedef enum {
    TY_UART_PARITY_NONE         = 0,   
    TY_UART_PARITY_ODD          = 1,  
    TY_UART_PARITY_EVEN         = 2,   
} TY_UART_PARITY_E;

typedef enum {
    TY_UART_INT_TX_EVENT        = 1,   
    TY_UART_INT_RX_EVENT        = 2,   
} TY_UART_EVENT_E;

typedef enum {
    TY_UART_CONFIG_CMD          = 1,   
} TY_UART_CMD_E;

typedef struct {
    UINT_T              baudrate;
    UINT16_T            flag;
    UINT16_T            bufsz;
    UINT16_T            data_bits   :4;
    UINT16_T            stop_bits   :2;
    UINT16_T            parity      :2;
    UINT16_T            reserved    :8;
} TY_UART_CFG_S;


typedef struct TY_UART_DEV TY_UART_DEV_S;

typedef struct {
    INT_T   (*tx_finish)  (TY_UART_DEV_S *uart, VOID *buffer);
    INT_T   (*rx_notify)  (TY_UART_DEV_S *uart, UINT16_T size);
} TY_UART_CB_S;

typedef struct {
    INT_T   (*init)       (UINT8_T port, TY_UART_CFG_S *cfg);
    INT_T   (*send_byte)  (UINT8_T port, UINT8_T  byte);
    INT_T   (*read_byte)  (UINT8_T port, UINT8_T *byte);
    INT_T   (*control)    (UINT8_T port, UINT8_T cmd, VOID *arg);
    INT_T   (*deinit)     (UINT8_T port);
} TY_UART_OPS_S;

struct TY_UART_DEV {    
    UINT8_T             port;
    TY_UART_CFG_S       cfg;
    TY_UART_CB_S        cb;
    TY_UART_OPS_S       *ops;
    VOID                *rx;
};

/*============================ LOCAL VARIABLES ===============================*/
/*============================ PROTOTYPES ====================================*/
INT_T ty_hal_uart_init(TY_UART_DEV_S *uart);
INT_T ty_uart_send(TY_UART_DEV_S *uart, VOID *data, UINT16_T len);
INT_T ty_uart_read(TY_UART_DEV_S *uart, VOID *data, UINT16_T len);
INT_T ty_uart_control(TY_UART_DEV_S *uart, UINT8_T cmd, VOID *arg);
INT_T ty_uart_deinit(TY_UART_DEV_S *uart);


INT_T ty_uart_register(TY_UART_DEV_S *uart);
VOID ty_uart_isr(TY_UART_DEV_S *uart, UINT_T event);
#endif


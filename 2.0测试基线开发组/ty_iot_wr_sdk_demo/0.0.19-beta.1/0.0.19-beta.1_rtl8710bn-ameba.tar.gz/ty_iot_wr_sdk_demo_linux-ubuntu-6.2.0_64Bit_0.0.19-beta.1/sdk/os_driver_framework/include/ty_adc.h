 /*============================================================================
 *                                                                            *
 * Copyright (C) by Tuya Inc                                                  *
 * All rights reserved                                                        *
 *                                                                            *
 =============================================================================*/

#ifndef __TY_ADC_H__
#define __TY_ADC_H__
/*============================ INCLUDES ======================================*/
#include "ty_hal.h"

/*============================ MACROS ========================================*/
/*============================ TYPES =========================================*/
typedef enum {
    TY_ADC0  = 0,                  
    TY_ADC1,       
    TY_ADC2,          
} TY_ADC_PORT_E;

typedef struct {
    UINT8_T     pin;
    UINT8_T     flag;
} TY_ADC_CFG_S;

typedef struct {
    INT_T (*init)         (UINT8_T port, TY_ADC_CFG_S *cfg);
    INT_T (*convert)      (UINT8_T port, UINT16_T *result, UINT16_T num);
    INT_T (*control)      (UINT8_T port, UINT8_T cmd, VOID *arg);
    INT_T (*deinit)       (UINT8_T port);
} TY_ADC_OPS_S;

typedef struct {
    UINT8_T                 port;
    TY_ADC_CFG_S            cfg;    
    TY_ADC_OPS_S            *ops;
} TY_ADC_DEV_S;

/*============================ PROTOTYPES ====================================*/
INT_T ty_adc_init(TY_ADC_DEV_S *adc);
INT_T ty_adc_convert(TY_ADC_DEV_S *adc, UINT16_T *result, UINT16_T num);
INT_T ty_adc_control(TY_ADC_DEV_S *adc, UINT8_T cmd, VOID *arg);
INT_T ty_adc_deinit(TY_ADC_DEV_S *adc);

INT_T ty_adc_register(TY_ADC_DEV_S  *adc);

#endif

/**
 * @file tuya_sdk.h
 * @author maht@tuya.com
 * @brief SDK通用流程管理，SDK对象管理模块
 * @version 0.1
 * @date 2019-08-28
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#ifndef __TUYA_DEV_H__
#define __TUYA_DEV_H__


#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief tuya iot sdk初始化接口
 * 
 * @param[in] storage_path 
 * @param[in] init_params 
 * @return int 0表示成功，非0请参照tuya error code描述文档
 */
int tuya_sdk_init(const char *storage_path, const void *init_params);

/**
 * @brief 
 * 
 * @param reg_flag 
 * @return int 
 */
int tuya_sdk_register(const char reg_flag);

/**
 * @brief 
 * 
 * @param unreg_flag 
 * @return int 
 */
int tuya_sdk_unregister(const char unreg_flag);

/**
 * @brief 
 * 
 * @param active_flag 
 * @return int 
 */
int tuya_sdk_active(const char active_flag);

/**
 * @brief 
 * 
 * @param unactive_flag 
 * @return int 
 */
int tuya_sdk_unactive(const char unactive_flag);

/**
 * @brief 
 * 
 * @return int 
 */
int tuya_sdk_reset(const char reset_flag);

/**
 * @brief 获取sdk版本信息
 * 
 * @return char*：sdk版本号
 */
char* tuya_sdk_get_version(void);

/**
 * @brief 获取sdk详细版本信息，包括sdk内部组件的版本信息
 * 
 * @return char*：sdk版本详细信息
 */
char* tuya_sdk_get_version_detail(void);

#ifdef __cplusplus
}
#endif


#endif

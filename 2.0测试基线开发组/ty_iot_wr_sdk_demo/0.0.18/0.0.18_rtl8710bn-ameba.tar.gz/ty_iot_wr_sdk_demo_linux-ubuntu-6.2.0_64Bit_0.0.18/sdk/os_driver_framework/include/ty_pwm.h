 /*============================================================================
 *                                                                            *
 * Copyright (C) by Tuya Inc                                                  *
 * All rights reserved                                                        *
 *                                                                            *
 * @author  :   Linch                                                         *
 * @date    :   2019-08-20                                                    *
 * @brief   :                                                                 *
 *                                                                            *
 =============================================================================*/

#ifndef __TY_PWM_H__
#define __TY_PWM_H__
/*============================ INCLUDES ======================================*/
#include "ty_hal.h"

/*============================ MACROS ========================================*/
/*============================ TYPES =========================================*/
/*============================ LOCAL VARIABLES ===============================*/
typedef enum {
    TY_PWM0 = 0x00,
    TY_PWM1,
    TY_PWM2,
    TY_PWM3,
    TY_PWM4,
    TY_PWM5,
} TY_PWM_PORT_E;

typedef enum {
    TY_PWM_SET_CMD = 0,
    TY_PWM_PERIOD_SET_CMD,
    TY_PWM_PULSE_SET_CMD,
} TY_PWM_CMD_E;

typedef struct {
    UINT8_T         pin;
    UINT_T          period_us;
    UINT_T          pulse_us;
} TY_PWM_CFG_S;

typedef struct {
    INT_T (*init)     (UINT8_T  port, TY_PWM_CFG_S *cfg);
    INT_T (*start)    (UINT8_T  port);
    INT_T (*stop)     (UINT8_T  port);
    INT_T (*control)  (UINT8_T  port, UINT8_T cmd, VOID *arg);
    INT_T (*deinit)   (UINT8_T  port);
} TY_PWM_OPS_S;

typedef struct {
    UINT8_T         port;
    TY_PWM_CFG_S    cfg;
    TY_PWM_OPS_S    *ops;
} TY_PWM_DEV_S;

/*============================ PROTOTYPES ====================================*/
INT_T ty_pwm_init(TY_PWM_DEV_S *pwm);
INT_T ty_pwm_start(TY_PWM_DEV_S *pwm);
INT_T ty_pwm_stop(TY_PWM_DEV_S *pwm);
INT_T ty_pwm_control(TY_PWM_DEV_S *pwm, UINT8_T cmd, VOID *arg);
INT_T ty_pwm_deinit(TY_PWM_DEV_S *pwm);
INT_T ty_pwm_set(TY_PWM_DEV_S *pwm, UINT_T period_us, UINT_T pulse_us);
INT_T ty_pwm_period_set(TY_PWM_DEV_S *pwm, UINT_T period_us);
INT_T ty_pwm_pulse_set(TY_PWM_DEV_S *pwm, UINT_T pulse_us);


INT_T ty_pwm_register(TY_PWM_DEV_S  *pwm);

#endif


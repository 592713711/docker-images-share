 /*============================================================================
 *                                                                            *
 * Copyright (C) by Tuya Inc                                                  *
 * All rights reserved                                                        *
 *                                                                            *
 =============================================================================*/

#ifndef __TY_I2C_H__
#define __TY_I2C_H__
/*============================ INCLUDES ======================================*/
#include "ty_hal.h"

/*============================ MACROS ========================================*/
#define TY_I2C_WR                0x0000
#define TY_I2C_RD               (1 << 0)
#define TY_I2C_ADDR_10BIT       (1 << 2)  /* this is a ten bit chip address */
#define TY_I2C_NO_START         (1 << 4)
#define TY_I2C_IGNORE_NACK      (1 << 5)
#define TY_I2C_NO_READ_ACK      (1 << 6)  /* when I2C reading, we do not ACK */


#define TY_SOFT_I2C0_MASTER_INIT(__I2C, __ADDR, __SCL, __SDA)       \
    (__I2C)->port = TY_SOFT_I2C0;                                   \
    (__I2C)->cfg.dev_addr               = __ADDR;                   \
    (__I2C)->cfg.mode                   = TY_I2C_MODE_MASTER;       \
    (__I2C)->cfg.soft_adapt.scl_pin     = __SCL;                    \
    (__I2C)->cfg.soft_adapt.sda_pin     = __SDA;                    \
    (__I2C)->cfg.soft_adapt.delay_count = 43;                       \
    (__I2C)->cfg.soft_adapt.timeout     = 5


#define TY_SOFT_I2C1_INIT(__I2C, __SCL, __SDA)

/*============================ TYPES =========================================*/
typedef enum {
    TY_SOFT_I2C0 = 0,
    TY_SOFT_I2C1,
    TY_HARD_I2C0,
    TY_HARD_I2C1,
} TY_I2C_PORT_E;

typedef enum {
    TY_I2C_MODE_MASTER = 0,
    TY_I2C_MODE_SLAVE,
} TY_I2C_MODE_E;


typedef struct {
    UINT8_T             sda_pin;
    UINT8_T             scl_pin;
    UINT_T              delay_count;
    UINT_T              timeout;            //! wait ack timeout (timeout * delay_count)
} TY_I2C_SOFT_ADAPT_S;

typedef struct {
    UINT8_T                 mode;
    UINT16_T                dev_addr;
    TY_I2C_SOFT_ADAPT_S     soft_adapt;
} TY_I2C_CFG_S;

typedef struct {
    UINT16_T                addr;
    UINT16_T                flags;
    UINT16_T                len;
    UINT8_T                 *buf;
} TY_I2C_MSG_S;

typedef struct {
    INT_T   (*init)       (UINT8_T port, TY_I2C_CFG_S *cfg);
    INT_T   (*xfer)       (UINT8_T port, TY_I2C_MSG_S *msg, UINT8_T num);
    INT_T   (*control)    (UINT8_T port, UINT8_T cmd, VOID *arg);
    INT_T   (*deinit)     (UINT8_T port);
} TY_I2C_OPS_S;

typedef struct {
    UINT8_T         port;
    TY_I2C_CFG_S    cfg;
    TY_I2C_OPS_S    *ops;
} TY_I2C_DEV_S;


/*============================ PROTOTYPES ====================================*/
INT_T ty_soft_i2c_init(TY_I2C_DEV_S *i2c);
INT_T ty_hard_i2c_init(TY_I2C_DEV_S *i2c);

INT_T ty_i2c_xfer(TY_I2C_DEV_S *i2c, TY_I2C_MSG_S *msg, UINT8_T num);
INT_T ty_i2c_control(TY_I2C_DEV_S *i2c, UINT8_T cmd, VOID *arg);
INT_T ty_i2c_deinit(TY_I2C_DEV_S *i2c);

INT_T ty_i2c_master_send(TY_I2C_DEV_S *i2c, UINT16_T addr, UINT16_T flags, VOID *buf, UINT16_T count);
INT_T ty_i2c_master_recv(TY_I2C_DEV_S *i2c, UINT16_T addr, UINT16_T flags, VOID *buf, UINT16_T count);


INT_T ty_i2c_hard_register(TY_I2C_DEV_S *i2c);

#endif
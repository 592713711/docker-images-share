 /*============================================================================
 *                                                                            *
 * Copyright (C) by Tuya Inc                                                  *
 * All rights reserved                                                        *
 *                                                                            *
 =============================================================================*/

#ifndef __TY_I2S_H__
#define __TY_I2S_H__
/*============================ INCLUDES ======================================*/
#include "ty_hal.h"

/*============================ MACROS ========================================*/
/*============================ TYPES =========================================*/
typedef enum {
    TY_I2S0  = 0,                  
    TY_I2S1,       
} TY_I2S_PORT_E;

typedef enum {
    TY_I2S_FREQ_8K         = 8000,        
    TY_I2S_FREQ_16K        = 16000,                  
    TY_I2S_FREQ_22K        = 22050,  
    TY_I2S_FREQ_32K        = 32000,  
    TY_I2S_FREQ_44K        = 44100,  
    TY_I2S_FREQ_48K        = 48000,  
} TY_I2S_FREQ_E;

typedef enum {
    TY_I2S_DATA_BIT8        = 8,                  
    TY_I2S_DATA_BIT16       = 16,
    TY_I2S_DATA_BIT24       = 24,      
    TY_I2S_DATA_BIT32       = 32,        
} TY_I2S_DATA_BITS_E;

typedef enum {
    TY_I2S_CHANNEL_MONO     = 1,                  
    TY_I2S_CHANNEL_STEREO   = 2,
} TY_I2S_CHANNEL_E;

typedef enum {
    TY_I2S_STANDARD_PHILIPS  = 1,               
    TY_I2S_STANDARD_MSB,
    TY_I2S_STANDARD_LSB,
} TY_I2S_STANDARD_E;

typedef enum {
    TY_I2S_MODE_TX  = 1,               
    TY_I2S_MODE_RX,
    TY_I2S_MODE_TXRX,
} TY_I2S_MODE_E;

typedef enum {
    TY_I2S_START_CMD  = 1,               
    TY_I2S_STOP_CMD,
} TY_I2S_CMD_E;

typedef struct {
    TY_I2S_MODE_E       mode;
    TY_I2S_FREQ_E       freq;
    TY_I2S_CHANNEL_E    cahnnel;
    TY_I2S_STANDARD_E   standard;
    TY_I2S_DATA_BITS_E  data_bits;
} TY_I2S_CFG_S;

typedef struct {
    INT_T (*init)         (UINT8_T port, TY_I2S_CFG_S *cfg);
    INT_T (*write)        (UINT8_T port, VOID *data, UINT_T length);
    INT_T (*read)         (UINT8_T port, VOID *data, UINT_T length);
    INT_T (*control)      (UINT8_T port, UINT8_T cmd, VOID *arg);
    INT_T (*deinit)       (UINT8_T port);
} TY_I2S_OPS_S;

typedef struct {
    UINT8_T                 port;
    TY_I2S_CFG_S            cfg;    
    TY_I2S_OPS_S            *ops;
} TY_I2S_DEV_S;

/*============================ PROTOTYPES ====================================*/
INT_T ty_i2s_init(TY_I2S_DEV_S *i2s);
INT_T ty_i2s_start(TY_I2S_DEV_S *i2s);
INT_T ty_i2s_stop(TY_I2S_DEV_S *i2s);
INT_T ty_i2s_write(TY_I2S_DEV_S *i2s, VOID *data, UINT_T length);
INT_T ty_i2s_read(TY_I2S_DEV_S *i2s,  VOID *data, UINT_T length);
INT_T ty_i2s_control(TY_I2S_DEV_S *i2s, UINT8_T cmd, VOID *arg);
INT_T ty_i2s_deinit(TY_I2S_DEV_S *i2s);


INT_T ty_i2s_register(TY_I2S_DEV_S  *i2s);

#endif

 /*============================================================================
 *                                                                            *
 * Copyright (C) by Tuya Inc                                                  *
 * All rights reserved                                                        *
 *                                                                            *
 =============================================================================*/

#ifndef __TY_PIN_H__
#define __TY_PIN_H__

/*============================ INCLUDES ======================================*/
#include "ty_hal.h"

/*============================ MACROS ========================================*/
#define TY_PINS_NAME(PORT)  PORT##0,  PORT##1,  PORT##2,  PORT##3,  PORT##4,  \
                            PORT##5,  PORT##6,  PORT##7,  PORT##8,  PORT##9,  \
                            PORT##10, PORT##11, PORT##12, PORT##13, PORT##14, \
                            PORT##15, PORT##16, PORT##17, PORT##18, PORT##19, \
                            PORT##20, PORT##21, PORT##22, PORT##23, PORT##24, \
                            PORT##25, PORT##26, PORT##27, PORT##28, PORT##29, \
                            PORT##30, PORT##31 

//! 2bit
#define TY_PIN_INIT_LOW         ((UINT16_T)(0x01 << 0))
#define TY_PIN_INIT_HIGH        ((UINT16_T)(0x02 << 0))
#define TY_PIN_INIT_MASK        ((UINT16_T)(0x03 << 0))

//! 3bit
#define TY_PIN_IN               ((UINT16_T)(0x01 << 2))
#define TY_PIN_IN_FL            ((UINT16_T)(0x02 << 2))
#define TY_PIN_IN_IRQ           ((UINT16_T)(0x03 << 2))
#define TY_PIN_OUT_PP           ((UINT16_T)(0x04 << 2))
#define TY_PIN_OUT_OD           ((UINT16_T)(0x05 << 2))
#define TY_PIN_INOUT_MASK       ((UINT16_T)(0x07 << 2))

//! 3bit
#define TY_PIN_IRQ_RISE         ((UINT16_T)(0x01 << 5))
#define TY_PIN_IRQ_FALL         ((UINT16_T)(0x02 << 5))
#define TY_PIN_IRQ_RISE_FALL    ((UINT16_T)(0x03 << 5))
#define TY_PIN_IRQ_LOW          ((UINT16_T)(0x04 << 5))
#define TY_PIN_IRQ_HIGH         ((UINT16_T)(0x05 << 5))
#define TY_PIN_IRQ_MASK         ((UINT16_T)(0x07 << 5))

//! 4bit 
#define TY_PIN_PULL_UP          ((UINT16_T)(0x01 << 9))
#define TY_PIN_PULL_DOWN        ((UINT16_T)(0x02 << 9))
#define TY_PIN_PULL_NONE        ((UINT16_T)(0x03 << 9))
#define TY_PIN_MODE_MASK        ((UINT16_T)(0x0F << 9))

/*============================ TYPES =========================================*/
//! 3bit(bit7-bit5) port   5bit(bit4-bit0) pinmun
typedef enum {
    TY_PA = (0 << 5),
    TY_PB = (1 << 5),
    TY_PC = (2 << 5),
    TY_PD = (3 << 5),
    TY_PE = (4 << 5),
} TY_PIN_PORT_E;

//! TY_PA ->  TY_PA0 - TY_PA31
//! TY_PB ->  TY_PB0 - TY_PB31
//! TY_PC ->  TY_PC0 - TY_PC31
//! TY_PD ->  TY_PD0 - TY_PD31
//! TY_PE ->  TY_PE0 - TY_PE31
typedef enum {
    TY_PINS_NAME(TY_PA),
    TY_PINS_NAME(TY_PB),
    TY_PINS_NAME(TY_PC),
    TY_PINS_NAME(TY_PD),
    TY_PINS_NAME(TY_PE),
} TY_PIN_NAME_E;

typedef enum {
    TY_PIN_LOW  = 0,
    TY_PIN_HIGH
} TY_PIN_STAT_E;

typedef enum {
    //! PU  ->  pull up
    //! PD  ->  pull dowm
    //! FL  ->  floating
    //! PP  ->  push pull
    //! OD  ->  open drain
    //! hiz ->  high-impedance level

    TY_PIN_MODE_IN_PU               = TY_PIN_IN     | TY_PIN_PULL_UP,
    TY_PIN_MODE_IN_PD               = TY_PIN_IN     | TY_PIN_PULL_DOWN,
    TY_PIN_MODE_IN_FL               = TY_PIN_IN_FL,

    TY_PIN_MODE_IN_IRQ_RISE         = TY_PIN_IN_IRQ | TY_PIN_IRQ_RISE | TY_PIN_PULL_UP, 
    TY_PIN_MODE_IN_IRQ_FALL         = TY_PIN_IN_IRQ | TY_PIN_IRQ_FALL | TY_PIN_PULL_UP,
    TY_PIN_MODE_IN_IRQ_RISE_FALL    = TY_PIN_IN_IRQ | TY_PIN_IRQ_RISE_FALL | TY_PIN_PULL_UP,
    TY_PIN_MODE_IN_IRQ_LOW          = TY_PIN_IN_IRQ | TY_PIN_IRQ_LOW   | TY_PIN_PULL_UP,
    TY_PIN_MODE_IN_IRQ_HIGH         = TY_PIN_IN_IRQ | TY_PIN_IRQ_HIGH  | TY_PIN_PULL_UP,
    
    TY_PIN_MODE_OUT_PP_LOW          = TY_PIN_OUT_PP | TY_PIN_INIT_LOW,
    TY_PIN_MODE_OUT_PP_HIGH         = TY_PIN_OUT_PP | TY_PIN_INIT_HIGH,

    TY_PIN_MODE_OUT_PP_PU_LOW       = TY_PIN_OUT_PP | TY_PIN_PULL_UP | TY_PIN_INIT_LOW,
    TY_PIN_MODE_OUT_PP_PU_HIGH      = TY_PIN_OUT_PP | TY_PIN_PULL_UP | TY_PIN_INIT_HIGH,

    TY_PIN_MODE_OUT_PP_PD_LOW       = TY_PIN_OUT_PP | TY_PIN_PULL_DOWN | TY_PIN_INIT_LOW,
    TY_PIN_MODE_OUT_PP_PD_HIGH      = TY_PIN_OUT_PP | TY_PIN_PULL_DOWN | TY_PIN_INIT_HIGH,

    TY_PIN_MODE_OUT_OD_LOW          = TY_PIN_OUT_OD | TY_PIN_INIT_LOW,
    TY_PIN_MODE_OUT_OD_HIZ          = TY_PIN_OUT_OD | TY_PIN_INIT_HIGH,

    TY_PIN_MODE_OUT_OD_PU_LOW       = TY_PIN_OUT_OD | TY_PIN_PULL_UP | TY_PIN_INIT_LOW,
    TY_PIN_MODE_OUT_OD_PU_HIGH      = TY_PIN_OUT_OD | TY_PIN_PULL_UP | TY_PIN_INIT_HIGH,
} TY_PIN_MODE_E;

typedef enum {
    TY_PIN_IRQ_CONFIG_CMD       = 1,
    TY_PIN_IRQ_ENABLE_CMD       = 2,
    TY_PIN_IRQ_DISABLE_CMD      = 3,
} TY_PIN_CONTROL_CMD_E;

typedef VOID (*TY_PIN_IRQ_CB)(VOID *args);

typedef struct {
    UINT16_T        mode;
    TY_PIN_IRQ_CB   cb;
    VOID            *arg;
} TY_PIN_IRQ_CFG_S;

typedef struct {
    INT_T   (*init)       (UINT8_T pin, UINT16_T mode);
    INT_T   (*write)      (UINT8_T pin, UINT8_T  level);
    INT_T   (*read)       (UINT8_T pin);
    INT_T   (*toggle)     (UINT8_T pin);
    INT_T   (*control)    (UINT8_T pin, UINT8_T cmd, VOID *arg);
} TY_PIN_OPS_S;

typedef struct {
    TY_PIN_OPS_S    *ops;
} TY_PIN_DEV_S;

/*============================ PROTOTYPES ====================================*/
INT_T ty_pin_init(UINT8_T pin, UINT16_T mode);
INT_T ty_pin_write(UINT8_T pin, UINT8_T level);
INT_T ty_pin_read(UINT8_T pin);
INT_T ty_pin_control(UINT8_T pin, UINT8_T cmd, void *arg);
INT_T ty_pin_irq_init(UINT8_T pin, UINT16_T irq_mode, TY_PIN_IRQ_CB cb, VOID *arg);
INT_T ty_pin_irq_enable(UINT8_T pin);
INT_T ty_pin_irq_disable(UINT8_T pin);


INT_T ty_pin_register(TY_PIN_DEV_S *pin);
#endif
